﻿using System;

namespace CoreCaptcha
{
    public class Class1
    {
    }
}
