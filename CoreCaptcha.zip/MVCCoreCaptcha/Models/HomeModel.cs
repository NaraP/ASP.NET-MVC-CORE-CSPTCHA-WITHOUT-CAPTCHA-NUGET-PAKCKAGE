﻿using System.ComponentModel.DataAnnotations;

namespace MVCCoreCaptcha.Models
{
    public class HomeModel
    {
        [Required]
        [StringLength(4)]
        public string CaptchaCode { get; set; }
    }
}
